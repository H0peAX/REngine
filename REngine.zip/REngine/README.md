# Como adicionar fotos e vídeos

O site busca as mídias sozinho pelas pastas `proj/fotos/` e `proj/videos/`. Basta colocar os arquivos com o nome certo — não precisa editar nenhum código.

## Nomes de cada projeto (slug)

| Card no site           | Slug        |
|------------------------|-------------|
| Astriel                | `astriel`   |
| Demiurgo                | `demiurgo`  |
| Ikarus                  | `ikarus`    |
| GaiaLocal                | `gaialocal` |
| PrimeLab                 | `primelab`  |
| Radar Bluetooth / Rede   | `radar`     |

## Fotos → `proj/fotos/`

Nomeie como `slug-1`, `slug-2`, ..., `slug-5` (até 5 fotos por projeto).
Extensões aceitas: `.jpg`, `.jpeg`, `.png`, `.webp`.

Exemplo, para o card Astriel:
```
proj/fotos/astriel-1.jpg
proj/fotos/astriel-2.png
```

## Vídeos → `proj/videos/`

Nomeie como `slug-1.mp4`, `slug-2.mp4` (até 2 vídeos por projeto). Formato: `.mp4`.

Exemplo:
```
proj/videos/astriel-1.mp4
```

## Não precisa numerar em sequência

Pode subir só a `-2` sem ter a `-1`, por exemplo — o site testa todos os números de 1 a 5 (fotos) e 1 a 2 (vídeos) e mostra só o que existir.

## Deploy

Suba a pasta inteira (com `index.html` e `proj/`) para o repositório do GitHub e ative o GitHub Pages. Assim que as fotos/vídeos estiverem nas pastas certas, eles aparecem automaticamente no carrossel de cada card, com setas e bolinhas de navegação — sem precisar mexer no HTML.

Se um card não tiver nenhuma foto/vídeo, ele continua mostrando o placeholder atual.
